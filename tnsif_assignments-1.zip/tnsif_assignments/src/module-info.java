/**
 * 
 */
/**
 * 
 */
module tnsif_assignments {
}
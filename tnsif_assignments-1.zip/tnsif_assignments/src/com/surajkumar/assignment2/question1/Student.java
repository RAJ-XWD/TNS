package com.surajkumar.assignment2.question1;

public class Student {
	// Default constructor
    public Student() {
        System.out.println("Student object is created");
    }

    public static void main(String[] args) {
        // Creating an object of the Student class
        Student student = new Student();
    }
}

package com.surajkumar.assignment2.question2;

public class main {
	    public static void main(String[] args) {
	        // Create an object of the Commission class
	        Commission employee = new Commission();

	        // Call the acceptDetails method to input sales employee details
	        employee.acceptDetails();

	        // Call the calculateCommission method to compute and display commission
	        employee.calculateCommission();
	    }
	}

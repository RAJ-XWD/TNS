package com.surajkumar.assignment3;

public interface Airfare {
	 double calculateAmount(); // Method to calculate the amount
	 void display(); // Method to display details
}
